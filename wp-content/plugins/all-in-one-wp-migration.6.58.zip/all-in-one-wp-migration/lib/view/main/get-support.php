<a href="https://servmask.com/help" target="_blank"><?php _e( 'Get Support', AI1WM_PLUGIN_NAME ); ?></a>
